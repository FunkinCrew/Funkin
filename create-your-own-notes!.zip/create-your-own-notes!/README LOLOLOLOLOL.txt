tl;dr

if using champions, use NOTE_assetss.xml/png
if using vanilla/any other mod, use NOTE_assets.xml/png

to create, an application with layers such as paintdotnet is required

add in your notes as layers, one from each folder

once desired colors are reached, save as a flat png and name accordingly.
add to game, and enjoy!

- Bloopydoopy